# h5案例打击乐

- 程序员文档编写格式 markdown 广泛的支持

  ``` javascript
  function bubbleSort(alist) {

  }
  ```

  | 项目 | 价格 | 数量 |
  | :-------- | --------:| :--: |
  | iphone| 3200元| 5|
  
- html5 是最酷的  网易
  强大表现力， 用html5 + css3 模拟一个PC 打击键盘
  导演 html 演员  css 化妆师， js 是武术指导
  模拟现实
  - 快速且准确的完成html结构编写
  vscode 内置支持emmet 
  emmet 快
  准确 html 实力

- stylus 除了可以省区 ： {} , 提供像
  js 一样的 模块化的能力 {   } block 
  代码的可读性提升 